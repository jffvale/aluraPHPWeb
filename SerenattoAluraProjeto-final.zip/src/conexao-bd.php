<?php

$pdo = new PDO('mysql:host=localhost;dbname=serenatto', 'root', '1234');
